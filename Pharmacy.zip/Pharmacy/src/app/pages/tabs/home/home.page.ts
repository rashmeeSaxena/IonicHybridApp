import { Component, OnInit } from '@angular/core';
import { Share } from '@capacitor/share';

// import Swiper core and required modules
import SwiperCore, { Keyboard, Pagination, SwiperOptions } from 'swiper';
// install Swiper modules
SwiperCore.use([Pagination, Keyboard]);
import {Router} from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  config: SwiperOptions = {
    slidesPerView: 1.1,
    // navigation: true,
    pagination: { clickable: true },
    keyboard: { enabled: true }
    // centeredSlides: true
  };
  route: any;

  constructor(private router:Router) { }

  async share(){
    await Share.share({
      title: 'See cool stuff',
      text: 'Really awesome thing you need to see right meow',
      url: 'https://limitlesshealth.com/',
      dialogTitle: 'Share with buddies',
});
  }
  ngOnInit() {
  }
  navigate() {
   
     //this.router.navigate(['/search'])

  }
}
