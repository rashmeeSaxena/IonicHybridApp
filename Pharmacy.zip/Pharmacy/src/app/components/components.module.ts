import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PharmacyComponent } from './pharmacy/pharmacy.component';
import { IonicModule } from '@ionic/angular';
import { LoadingPharmacyComponent } from './loading-pharmacy/loading-pharmacy.component';


@NgModule({
  declarations: [
    PharmacyComponent,
    LoadingPharmacyComponent
  ],
  imports: [
    CommonModule,
    IonicModule
  ],
  exports: [
    PharmacyComponent,
    LoadingPharmacyComponent
  ],
  entryComponents: []
})
export class ComponentsModule { }
